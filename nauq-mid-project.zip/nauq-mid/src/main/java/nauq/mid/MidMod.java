package nauq.mid;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

/**
 * NAUQ - "mid" modulu
 * - G: GUI acar (sadece elde fisek varken), ESC kapatir
 * - Module SOL tik: ac/kapa | SAG tik: ayarlar (speed 10-100) | ORTA tik: tus ata
 * - Elytra acikken fisek elindeyken oyuncuya vurursan: aninda kilica gecer, kilicla vurur, fisege doner.
 *   Kendi kendine vurmaz, sadece sen vurunca calisir.
 */
public class MidMod implements ClientModInitializer {

    static boolean enabled = true;
    static int speed = 50;          // 10..100
    static int bindKey = -1;        // GLFW key, -1 = yok

    static KeyBinding openKey;
    static boolean bindWasDown = false;

    static int pending = -1;        // kalan tick, -1 = bekleyen yok
    static Entity pendingTarget;
    static int returnSlot = 0;
    static boolean selfAttack = false;

    static boolean holdingRocket(PlayerEntity p) {
        return p.getMainHandStack().isOf(Items.FIREWORK_ROCKET)
            || p.getOffHandStack().isOf(Items.FIREWORK_ROCKET);
    }

    // speed 100 -> 0 tick (ayni tick), speed 10 -> 4 tick
    static int delayTicks() {
        return Math.round((100 - speed) / 22.5f);
    }

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.nauq.mid.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.nauq"));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null) { pending = -1; return; }

            // G -> GUI (1 kere basinca acilir, sadece fisek varken)
            while (openKey.wasPressed()) {
                if (mc.currentScreen == null && holdingRocket(mc.player)) {
                    mc.setScreen(new MidScreen());
                }
            }

            // atanan tus -> modul ac/kapa
            if (bindKey > 0 && mc.currentScreen == null) {
                boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), bindKey);
                if (down && !bindWasDown) enabled = !enabled;
                bindWasDown = down;
            }

            // bekleyen kilic vurusu
            if (pending > 0) {
                pending--;
            } else if (pending == 0) {
                pending = -1;
                doSwordHit(mc);
            }
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClient || selfAttack || !enabled) return ActionResult.PASS;
            if (!(entity instanceof PlayerEntity)) return ActionResult.PASS;
            if (!player.isFallFlying() || !player.getMainHandStack().isOf(Items.FIREWORK_ROCKET)) {
                return ActionResult.PASS;
            }

            int sword = -1;
            for (int i = 0; i < 9; i++) {
                if (player.getInventory().getStack(i).getItem() instanceof SwordItem) { sword = i; break; }
            }
            if (sword == -1) return ActionResult.PASS;

            returnSlot = player.getInventory().selectedSlot;
            player.getInventory().selectedSlot = sword;
            pendingTarget = entity;

            int d = delayTicks();
            if (d == 0) {
                doSwordHit(MinecraftClient.getInstance());
            } else {
                pending = d;
            }
            return ActionResult.FAIL; // fisekli vurusu iptal et, yerine kilic vurusu gelir
        });
    }

    static void doSwordHit(MinecraftClient mc) {
        if (mc.player == null || mc.interactionManager == null || pendingTarget == null) return;
        if (pendingTarget.isAlive()) {
            selfAttack = true;
            mc.interactionManager.attackEntity(mc.player, pendingTarget);
            mc.player.swingHand(Hand.MAIN_HAND);
            selfAttack = false;
        }
        mc.player.getInventory().selectedSlot = returnSlot; // fisege geri don
        pendingTarget = null;
    }

    // ---------------------------------------------------------------- GUI
    static class MidScreen extends Screen {
        static final int BOX_W = 120, BOX_H = 20;
        boolean settingsOpen = false;
        boolean listening = false;
        boolean dragging = false;

        MidScreen() { super(Text.literal("NAUQ")); }

        int bx() { return width / 2 - BOX_W / 2; }
        int by() { return height / 2 - 40; }
        int sx() { return bx(); }
        int sy() { return by() + BOX_H + 18; }

        @Override
        public void render(DrawContext ctx, int mx, int my, float delta) {
            renderBackground(ctx);
            ctx.drawCenteredTextWithShadow(textRenderer, "NAUQ", width / 2, by() - 16, 0xFFFFFFFF);

            int col = enabled ? 0xFF2E9E4F : 0xFF444444;
            ctx.fill(bx(), by(), bx() + BOX_W, by() + BOX_H, col);
            ctx.drawCenteredTextWithShadow(textRenderer, "mid", width / 2, by() + 6, 0xFFFFFFFF);

            String bindText = listening ? "[ tusa bas... ]"
                : (bindKey > 0 ? "[" + InputUtil.fromKeyCode(bindKey, 0).getLocalizedText().getString() + "]" : "[yok]");
            ctx.drawText(textRenderer, bindText, bx() + BOX_W + 6, by() + 6, 0xFFAAAAAA, false);

            if (settingsOpen) {
                ctx.drawText(textRenderer, "speed: " + speed, sx(), sy() - 11, 0xFFFFFFFF, true);
                ctx.fill(sx(), sy(), sx() + BOX_W, sy() + 6, 0xFF333333);
                int hx = sx() + (int) ((speed - 10) / 90f * (BOX_W - 4));
                ctx.fill(sx(), sy(), hx + 2, sy() + 6, 0xFF2E9E4F);
                ctx.fill(hx, sy() - 2, hx + 4, sy() + 8, 0xFFFFFFFF);
            }
            ctx.drawCenteredTextWithShadow(textRenderer,
                "Sol: ac/kapa  Sag: ayar  Orta: tus ata  ESC: kapat", width / 2, height - 20, 0xFF888888);

            if (listening) {
                ctx.fill(0, 0, width, height, 0xDD000000);
                ctx.getMatrices().push();
                ctx.getMatrices().scale(4f, 4f, 1f);
                ctx.drawCenteredTextWithShadow(textRenderer, "Bir tu\u015fa bas",
                    width / 2 / 4, (height / 2 - 40) / 4, 0xFFFFFFFF);
                ctx.getMatrices().pop();
                ctx.getMatrices().push();
                ctx.getMatrices().scale(2f, 2f, 1f);
                ctx.drawCenteredTextWithShadow(textRenderer, "\u00c7\u0131kmak i\u00e7in ESC bas",
                    width / 2 / 2, (height / 2 + 10) / 2, 0xFFAAAAAA);
                ctx.getMatrices().pop();
            }
        }

        boolean overBox(double mx, double my) {
            return mx >= bx() && mx <= bx() + BOX_W && my >= by() && my <= by() + BOX_H;
        }

        void setSpeedFromMouse(double mx) {
            double t = (mx - sx()) / (double) (BOX_W - 4);
            speed = (int) Math.round(10 + Math.max(0, Math.min(1, t)) * 90);
        }

        @Override
        public boolean mouseClicked(double mx, double my, int button) {
            if (listening) return true;
            if (overBox(mx, my)) {
                if (button == 0) enabled = !enabled;
                else if (button == 1) settingsOpen = !settingsOpen;
                else if (button == 2) listening = true;
                return true;
            }
            if (settingsOpen && button == 0 && mx >= sx() && mx <= sx() + BOX_W
                && my >= sy() - 4 && my <= sy() + 10) {
                dragging = true;
                setSpeedFromMouse(mx);
                return true;
            }
            return super.mouseClicked(mx, my, button);
        }

        @Override
        public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
            if (dragging) { setSpeedFromMouse(mx); return true; }
            return super.mouseDragged(mx, my, button, dx, dy);
        }

        @Override
        public boolean mouseReleased(double mx, double my, int button) {
            dragging = false;
            return super.mouseReleased(mx, my, button);
        }

        @Override
        public boolean keyPressed(int key, int scan, int mods) {
            if (listening) {
                if (key != GLFW.GLFW_KEY_ESCAPE) bindKey = key; // ESC = atama yapma, sadece cik
                listening = false;
                return true;
            }
            return super.keyPressed(key, scan, mods); // ESC ekrani kapatir
        }

        @Override
        public boolean shouldPause() { return false; }
    }
}
